---
title: "TODO"
category: "dev"
tags: ["todo", "dev"]
date: "2024.08.11"
time: "11:14"
excerpt: "Way to prod"
---

## 0.1

- [x] category page
- [x] upgrade tag page
- [x] add github link somewhere
- [x] add contact info and some about info
- [x] custom routes and components
- [x] custom home page opt-in
- [x] killer home page
- [ ] documentations an tutorials
- [ ] update readme files (github and online)
- [ ] fix link for github readme
- [ ] include font and highligh js files, not as dependency but as vendor code

## 0.2

- [ ] multilanguage
- [x] search: json or google?
- [ ] seo things on frontmatter
- [ ] error handling
- [ ] accessibility
- [x] rewrite search.js to typesript
- [ ] organize packages

## 0.3

- [ ] rss ??
- [ ] xml site map???

## ...

## 1.0

- [ ] profit
