package config

var (
	Title               = "lt2"
	IndexTitle          = "Static site generator with markdown, templ and go"
	DateLayout          = "2006.01.02"
	TimeLayout          = "15:04"
	GeneretareFilesJson = true
)
